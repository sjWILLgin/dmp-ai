# 数据资产管理平台（前端雏形）

## 运行

```bash
# 1) 安装依赖
npm install

# 2) 启动
npm run dev
```

浏览器打开 Vite 输出的地址（默认 http://localhost:5173）。

## 你关心的修改点

- 左侧菜单：`src/layout/AppLayout.tsx` 里的 `menuItems`
- 路由页面：`src/App.tsx`
- 主数据中心（模块三）：`src/pages/MdmCenterPage.tsx` + `src/store/useMdmStore.ts`
- 资产详情抽屉：`src/components/asset/AssetDetail.tsx`
- 资产大类标签：`src/utils/assetCategory.tsx`
- 假数据：
  - 资产：`src/store/useAppStore.ts` 的 `seedAssets`
  - 主数据：`src/store/useMdmStore.ts`
