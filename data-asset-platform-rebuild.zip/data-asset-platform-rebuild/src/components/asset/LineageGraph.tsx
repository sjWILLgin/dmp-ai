import { Card, Space, Tree, Typography } from 'antd'
import React from 'react'
import { useAppStore } from '../../store/useAppStore'

const { Text } = Typography

type Node = { key: string; title: React.ReactNode; children?: Node[] }

const lineageMap: Record<string, { upstream: string[]; downstream: string[] }> = {
  a_ads_order: { upstream: ['a_ods_order', 'a_dim_calendar', 'a_mdm_customer'], downstream: ['a_metric_trade_cust'] },
  a_mdm_customer: { upstream: [], downstream: ['a_ads_order', 'a_api_customer'] },
  a_ods_order: { upstream: [], downstream: ['a_ads_order'] },
  a_dim_calendar: { upstream: [], downstream: ['a_ads_order', 'a_metric_trade_cust'] },
  a_metric_trade_cust: { upstream: ['a_ads_order'], downstream: [] },
  a_api_customer: { upstream: ['a_mdm_customer'], downstream: [] },
}

export default function LineageGraph({ assetId }: { assetId: string }) {
  const assets = useAppStore((s) => s.assets)
  const openDrawer = useAppStore((s) => s.openDrawer)

  const getTitle = (id: string) => {
    const a = assets.find((x) => x.id === id)
    return (
      <span style={{ cursor: 'pointer' }} onClick={() => openDrawer('ASSET_DETAIL', { assetId: id })}>
        {a ? a.name : id}
        <Text type="secondary" style={{ marginLeft: 8 }}>
          {a ? `${a.domain} / ${a.system}` : ''}
        </Text>
      </span>
    )
  }

  const data = lineageMap[assetId] ?? { upstream: [], downstream: [] }

  const upstreamTree: Node[] = data.upstream.map((id) => ({ key: id, title: getTitle(id) }))
  const downstreamTree: Node[] = data.downstream.map((id) => ({ key: id, title: getTitle(id) }))

  return (
    <Space direction="vertical" size={12} style={{ width: '100%' }}>
      <Card size="small" title="上游来源" styles={{ body: { paddingTop: 8 } }}>
        {upstreamTree.length ? (
          <Tree selectable={false} defaultExpandAll treeData={upstreamTree} />
        ) : (
          <Text type="secondary">暂无上游（示例数据）</Text>
        )}
      </Card>

      <Card size="small" title="下游影响" styles={{ body: { paddingTop: 8 } }}>
        {downstreamTree.length ? (
          <Tree selectable={false} defaultExpandAll treeData={downstreamTree} />
        ) : (
          <Text type="secondary">暂无下游（示例数据）</Text>
        )}
      </Card>

      <Text type="secondary">
        说明：这里是雏形，用 Tree 模拟血缘关系。后续你给我 PRD 的血缘模型后，我们可以替换成真正的图谱组件。
      </Text>
    </Space>
  )
}
