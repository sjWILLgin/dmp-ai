import { Card, Col, Row, Space, Statistic, Table, Tag, Typography } from 'antd'
import React from 'react'
import { useAppStore } from '../store/useAppStore'
import { assetCategoryTag, inferAssetCategory } from '../utils/assetCategory'

const { Title, Text } = Typography

export default function DataMapPage() {
  const assets = useAppStore((s) => s.assets)
  const globalSearch = useAppStore((s) => s.globalSearch)
  const openDrawer = useAppStore((s) => s.openDrawer)

  const filtered = React.useMemo(() => {
    const q = globalSearch.trim().toLowerCase()
    if (!q) return assets
    return assets.filter((a) => {
      const blob = [a.name, a.domain, a.system, a.owner, ...a.tags].join(' ').toLowerCase()
      return blob.includes(q)
    })
  }, [assets, globalSearch])

  const byDomain = React.useMemo(() => {
    const m: Record<string, number> = {}
    filtered.forEach((a) => {
      m[a.domain] = (m[a.domain] ?? 0) + 1
    })
    return Object.entries(m)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
  }, [filtered])

  return (
    <div style={{ padding: 16 }}>
      <Space direction="vertical" size={12} style={{ width: '100%' }}>
        <div>
          <Title level={4} style={{ margin: 0 }}>
            数据地图（雏形）
          </Title>
          <Text type="secondary">用卡片+表格模拟“域-系统-资产”的快速浏览与跳转。</Text>
        </div>

        <Row gutter={12}>
          <Col xs={24} md={8}>
            <Card size="small">
              <Statistic title="当前检索命中资产数" value={filtered.length} />
            </Card>
          </Col>
          <Col xs={24} md={16}>
            <Card size="small" title="域分布（示例）">
              <Space wrap>
                {byDomain.map(([d, c]) => (
                  <Tag key={d}>
                    {d}：{c}
                  </Tag>
                ))}
              </Space>
            </Card>
          </Col>
        </Row>

        <Card size="small" title="资产一览（点击进入详情抽屉）">
          <Table
            size="small"
            rowKey="id"
            pagination={false}
            dataSource={filtered}
            onRow={(record) => ({
              onClick: () => openDrawer('ASSET_DETAIL', { assetId: record.id }),
            })}
            columns={[
              { title: '资产名', dataIndex: 'name' },
              { title: '大类', width: 120, render: (_, r) => assetCategoryTag(r.assetCategory ?? inferAssetCategory(r)) },
              { title: '域', dataIndex: 'domain', width: 120 },
              { title: '系统', dataIndex: 'system', width: 120 },
              { title: 'Owner', dataIndex: 'owner', width: 120 },
              { title: '标签', render: (_, r) => r.tags.slice(0, 3).map((t) => <Tag key={t}>{t}</Tag>) },
            ]}
          />
        </Card>
      </Space>
    </div>
  )
}
