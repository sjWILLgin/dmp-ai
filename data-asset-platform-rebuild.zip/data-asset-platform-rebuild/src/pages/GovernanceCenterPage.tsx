import { Card, Space, Table, Tag, Typography } from 'antd'
import React from 'react'

const { Title, Text } = Typography

export default function GovernanceCenterPage() {
  return (
    <div style={{ padding: 16 }}>
      <Space direction="vertical" size={12} style={{ width: '100%' }}>
        <div>
          <Title level={4} style={{ margin: 0 }}>
            数据治理中心
          </Title>
          <Text type="secondary">雏形：质量规则、问题清单、责任人追踪。</Text>
        </div>

        <Card size="small" title="质量规则（示例）">
          <Table
            size="small"
            rowKey="rule"
            pagination={false}
            dataSource={[
              { rule: '唯一性: customer_id 不重复', level: 'P0', owner: '数据治理组', status: 'RUNNING' },
              { rule: '完整性: phone 非空(主数据)', level: 'P1', owner: '数据治理组', status: 'RUNNING' },
              { rule: '范围: gmv >= 0', level: 'P2', owner: '王浩锦', status: 'PAUSED' },
            ]}
            columns={[
              { title: '规则', dataIndex: 'rule' },
              { title: '级别', dataIndex: 'level', width: 90, render: (v) => <Tag>{v}</Tag> },
              { title: '责任人', dataIndex: 'owner', width: 120 },
              {
                title: '运行状态',
                dataIndex: 'status',
                width: 120,
                render: (v) => <Tag color={v === 'RUNNING' ? 'green' : 'orange'}>{v}</Tag>,
              },
            ]}
          />
        </Card>

        <Card size="small" title="治理问题单（示例）">
          <Table
            size="small"
            rowKey="id"
            pagination={false}
            dataSource={[
              { id: 'ISSUE_101', title: 'mdm_customer_golden 唯一性 WARN', owner: '数据治理组', status: 'OPEN' },
              { id: 'ISSUE_102', title: 'ads_order_kpi_daily 延迟 2 小时', owner: '刘洋', status: 'INVESTIGATING' },
            ]}
            columns={[
              { title: 'ID', dataIndex: 'id', width: 120 },
              { title: '问题', dataIndex: 'title' },
              { title: '负责人', dataIndex: 'owner', width: 120 },
              {
                title: '状态',
                dataIndex: 'status',
                width: 140,
                render: (v) => <Tag color={v === 'OPEN' ? 'red' : 'blue'}>{v}</Tag>,
              },
            ]}
          />
        </Card>
      </Space>
    </div>
  )
}
